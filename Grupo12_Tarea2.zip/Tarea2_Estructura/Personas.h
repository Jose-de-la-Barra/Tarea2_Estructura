typedef struct Persona {
    char  name[50];
    long int  dangerCategory;
    long double  attackProb;
    long int category;
} Persona;




